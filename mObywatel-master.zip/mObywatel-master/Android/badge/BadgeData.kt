package pl.gov.coi.common.ui.ds.badge

sealed interface BadgeData {
  object BadgeDefault : BadgeData
}

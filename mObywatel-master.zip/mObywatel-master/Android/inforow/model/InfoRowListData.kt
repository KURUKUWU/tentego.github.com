package pl.gov.coi.common.ui.ds.inforow.model

data class InfoRowListData(
  val items: List<InfoRowData>,
)

package pl.gov.coi.common.ui.ds.checkbox.common.model

enum class CheckboxContentType {
  CONTENT_BOX,
  DEFAULT,
}


import PackageDescription

let package = Package(
  name: "app",
  products: [],
  targets: []
)

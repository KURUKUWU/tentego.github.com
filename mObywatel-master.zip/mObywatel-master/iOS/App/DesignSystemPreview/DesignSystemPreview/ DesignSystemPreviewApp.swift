import SwiftUI

@main
struct DesignSystemPreviewApp: App {
  var body: some Scene {
    WindowGroup {
      ContentView()
    }
  }
}

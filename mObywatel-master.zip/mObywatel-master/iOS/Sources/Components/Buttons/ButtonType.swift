import Foundation

public enum ButtonType {
  case large
  case largeDestructive
  case small
  case smallDestructive
  case iconLarge
  case iconLargeDestructive
  case iconSmall
  case iconSmallDestructive
}

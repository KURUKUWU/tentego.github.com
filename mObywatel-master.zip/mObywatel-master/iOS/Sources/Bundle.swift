import Foundation

public let bundle: Bundle = .module
